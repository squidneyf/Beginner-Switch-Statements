#include <iostream>
#include <iomanip> 
using namespace std;

int main (){
const int iONE = 1;
const int iTWO = 2;
const int iTHREE = 3;
const int iFOUR = 4;
const int iFIVE = 5;
const int iSIX = 6;
const int iSEVEN = 7;
const int iEIGHT = 8;
const int iNINE = 9;
const int iTEN = 10;
const int iELEVEN = 11;
const int iTWELVE = 12;

cout<< "Hello! My name is Sydney Fleming! I am a Student at Alabama A&M University! Enter a number between 1-12 to learn about me! "<< setw(10) << endl;

int x ;
//just declared my variable, now, we prepare for a switch statement!

cout << "  Enter a number to find out a fact!  "<< endl;
cin >> x;

switch(x){
case iONE:
puts(" I am a Capricorn!");
break; 
case iTWO:
puts(" I am a Sophomore Computer Science Major!");
break;
case iTHREE:
puts(" I am from Decherd Tennessee! It is a small farming/rural area!");
break;
case iFOUR:
puts("I love to volunteer in the community to help those around me better themselves!");
break;
case iFIVE:
puts(" I am a journey to better myself and my coding!");
break;
case iSIX:
puts("I like to listen to Reddit while I work on my coding, but sometimes it becomes distracting!");
break;
case iSEVEN:
puts("I am a member of Gamma Sigma Sigma National Service Sorority, I am the Lucky Number Seven SPR 2023!");
break;
case iEIGHT:
puts("The next project tha ti want to work on is more switch statements that can do more thing and then set them to a loop!");
break;
case iNINE:
puts("I am working on ways to make myself a more charsmatic person for my career");
break;
case iTEN:
puts("My favorite colors are: Yellow, Purple, Red, and Blue");
break;
case iELEVEN:
puts("like to watch youtube!");
break;
case iTWELVE:
puts("Farting");
break;
default:
puts("Oops, that an incorrect option!");
break;
}
}
